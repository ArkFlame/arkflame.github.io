'use strict';
const $=id=>document.getElementById(id);
const number=v=>Number.isFinite(v)?Math.max(0,Math.round(v)).toLocaleString('en-US'):'—';
const root=document.querySelector('.glass');
let tabId,host='',settings={enabled:true,excludedHosts:[]},busy=false,latest;
const siteEnabled=()=>!!host && settings.enabled && !settings.excludedHosts.includes(host);
function powerDisplay(){
  $('power').checked=settings.enabled;
  const coverage=siteEnabled()?(latest?.coverage||0):0;
  $('ring').style.setProperty('--coverage',coverage+'%');
  $('percent').textContent=coverage+'%';
  root.classList.toggle('is-off',!siteEnabled());
  $('powerLabel').textContent=!settings.enabled?'Paused':!host?'Unavailable':settings.excludedHosts.includes(host)?'Excluded':'Active';
  $('siteEnabled').checked=!!host && !settings.excludedHosts.includes(host);
  $('siteLabel').textContent=!host?'Unavailable':settings.excludedHosts.includes(host)?'Excluded':settings.enabled?'Active':'Ready';
}
function paint(data){
  latest=data;
  const n=v=>number(v),percent=siteEnabled()?Math.max(0,Math.min(100,Number(data.coverage)||0)):0;
  $('ring').style.setProperty('--coverage',percent+'%');
  $('percent').textContent=percent+'%';
  $('hidden').textContent=n(data.far);
  $('contained').textContent=n(data.contained);
  $('scans').textContent=n(data.scans);
  $('scanMs').textContent=Number.isFinite(data.workMs)?data.workMs.toFixed(1)+'ms':'—';
  $('tiles').textContent=n(data.gridCells);
  $('scanned').textContent=n(data.scanned);
  $('scanTypes').textContent=`${n(data.fullScans)} / ${n(data.localScans)}`;
  $('scrollRoot').textContent=data.scrollRoot||'Not detected';
  $('scrollRoot').title=data.scrollRoot||'';
  $('description').textContent=!siteEnabled()?'Paused':data.reason||'Ready';
  $('description').title=$('description').textContent;
  $('liveBadge').style.opacity='1';
}
async function refresh(){
  if(busy||!tabId||document.hidden)return;
  busy=true;
  try{paint(await chrome.tabs.sendMessage(tabId,{type:'status'}));}
  catch{
    $('description').textContent='Refresh the webpage';
    $('liveBadge').style.opacity='.4';
  }finally{busy=false;}
}
(async()=>{
  settings=await chrome.storage.local.get({enabled:true,excludedHosts:[]});
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  tabId=tab?.id;
  try { const url=new URL(tab.url);host=/^https?:$/.test(url.protocol)?url.hostname:'';}catch{}
  $('host').textContent=host||'Browser page';
  $('siteEnabled').disabled=!host;
  powerDisplay();
  $('power').addEventListener('change',async()=>{
    settings.enabled=$('power').checked;powerDisplay();await chrome.storage.local.set({enabled:settings.enabled});refresh();
  });
  $('siteEnabled').addEventListener('change',async()=>{
    if(!host)return;
    const hosts=new Set(settings.excludedHosts);
    if($('siteEnabled').checked) hosts.delete(host);else hosts.add(host);
    settings.excludedHosts=[...hosts];powerDisplay();
    await chrome.storage.local.set({excludedHosts:settings.excludedHosts});
    refresh();
  });
  if(!host){$('description').textContent='Browser pages not supported';return;}
  await refresh();
  // Only the open popup polls; no permanent background timer or page script traffic.
  setInterval(refresh,1000);
})();
