(() => {
  'use strict';
  if (!CSS.supports('content-visibility', 'auto') || !CSS.supports('contain-intrinsic-block-size', 'auto 200px')) return;
  const ATTR = 'data-gdo-contained', FAR = 'data-gdo-far', SIZE = '--gdo-intrinsic-block';
  const LEAVES = 'p,pre,blockquote,li,dt,dd,figcaption,h1,h2,h3,h4,h5,h6';
  const CANDIDATES = LEAVES + ',section,article,figure,picture,div,ul,ol,dl';
  const OUTSIDE = 'head,nav,header,footer,aside,form,dialog,[role="navigation"],[role="toolbar"],[role="dialog"],[role="menu"],[role="menubar"],[inert],[aria-hidden="true"],[contenteditable]:not([contenteditable="false"])';
  const UNSAFE = 'input,textarea,select,iframe,video,audio,canvas,object,embed,form,dialog,[role="dialog"],[contenteditable]:not([contenteditable="false"])';
  const LEAF = new Set(['P','PRE','BLOCKQUOTE','LI','DT','DD','FIGCAPTION','H1','H2','H3','H4','H5','H6']);
  const containerTags = new Set(['DIV','SECTION','ARTICLE','FIGURE','PICTURE','UL','OL','DL']);
  const applied = new Set(), originals = new WeakMap(), edited = new WeakMap(), geometryRejected = new WeakSet(), blockHeights = new WeakMap();
  // Spatial index: group cached candidates into scrollport-height tiles (not repeated DOM queries).
  const cellSize = 512, regions = new Map(), indexed = new WeakMap(), nearRecheck = new Map();
  let activeScrollRoot = null, fullRetries = 0;
  let scrollableCache = new WeakMap();
  const listeningRoots = new Set();
  const reasons = {};
  let settings = {enabled:true,excludedHosts:[]};
  let scheduled = 0, running = false, generation = 0, pendingRescan = 0, watcher;
  let io, lastUrl = location.href, regionTimer=0;
  // Full discovery only on startup/navigation/settings; subsequent changes are scanned locally.
  let fullRescan = true;
  const dirtyRoots = new Set();
  let lastMutationAt = 0;
  let farCount = 0, hiddenHeight = 0, totalScrollHeight = 0;
  const stats = {scanned:0,eligible:0,contained:0,far:0,added:0,scanMs:0,workMs:0,scans:0,scanType:'initial',scrollRoot:'unknown',reason:'Starting',cachedRegions:0,gridChecks:0,fullScans:0,localScans:0,coverage:0,hiddenHeight:0,trackedHeight:0,updatedAt:0};
  const stamp = () => performance.now();
  const active = () => settings.enabled && !settings.excludedHosts.includes(location.hostname);
  const reject = key => {reasons[key]=(reasons[key]||0)+1;return null;};
  const rootScroll = () => document.scrollingElement || document.documentElement;
  const px = value => parseFloat(value)||0;
  function scrollParent(e) {
    for (let p=e.parentElement; p && p!==document.body && p!==document.documentElement; p=p.parentElement) {
      let scrollable=scrollableCache.get(p);
      if (scrollable===undefined) {
        scrollable=p.clientHeight>0 && p.scrollHeight>p.clientHeight+48 &&
          /auto|scroll|overlay/.test(getComputedStyle(p).overflowY);
        scrollableCache.set(p,scrollable);
      }
      if(scrollable) return p;
    }
    return rootScroll();
  }
  function scrollView(p) {
    if (p===rootScroll() || p===document.body || p===document.documentElement) return {top:0,bottom:innerHeight,height:innerHeight};
    const r=p.getBoundingClientRect(),top=Math.max(0,r.top),bottom=Math.min(innerHeight,r.bottom);
    return {top,bottom,height:Math.max(0,bottom-top)};
  }
  function rootLabel(p) {return p?`${p.tagName.toLowerCase()}${p.id?'#'+p.id:''} (${p.scrollHeight}px / ${p.clientHeight}px)`:'No scroll container discovered';}
  function cellOf(e,scroller) {
    const b=e.getBoundingClientRect();
    const r=scroller===rootScroll()?{top:0}:scroller.getBoundingClientRect();
    return Math.floor((b.top-r.top+scroller.scrollTop)/cellSize);
  }
  function cacheCandidate(e,scroller) {
    if (!scroller || !e.isConnected) return;
    const cell=cellOf(e,scroller),existing=indexed.get(e);
    if (existing && existing.root===scroller && existing.cell===cell && regions.get(scroller)?.get(cell)?.has(e)) return;
    if(existing) regions.get(existing.root)?.get(existing.cell)?.delete(e);
    let grid=regions.get(scroller);if(!grid){grid=new Map();regions.set(scroller,grid);}
    let bucket=grid.get(cell);if(!bucket){bucket=new Set();grid.set(cell,bucket);}
    bucket.add(e);indexed.set(e,{root:scroller,cell});
    if (scroller!==rootScroll() && !listeningRoots.has(scroller) && scroller.scrollHeight>scroller.clientHeight+50) {
      // Each independent scrolling area needs its own passive grid cursor.
      listeningRoots.add(scroller);
      scroller.addEventListener('scroll',onRegionScroll,{passive:true});
    }
  }
  function scrollerFromContent() {
    if(activeScrollRoot?.isConnected && activeScrollRoot.scrollHeight>activeScrollRoot.clientHeight+48) return activeScrollRoot;
    const samples=document.querySelectorAll('p,pre,blockquote,article,main,[role="feed"],[role="article"]');
    let best=null,bestExtent=0;
    for(let i=0;i<samples.length && i<120;i+=Math.max(1,Math.floor(samples.length/75))) {
      const p=scrollParent(samples[i]),extent=p.scrollHeight-p.clientHeight;
      if(extent>bestExtent && p.clientHeight>40){best=p;bestExtent=extent;}
    }
    const p=rootScroll();if(p.scrollHeight-p.clientHeight>bestExtent && p.clientHeight>40) best=p;
    activeScrollRoot=best;return best;
  }
  function onRegionScroll() {
    if (!active() || regionTimer) return;
    regionTimer=requestAnimationFrame(()=>{regionTimer=0;revisitVisibleCells();});
  }
  function revisitVisibleCells() {
    // Only retry previously deferred candidates in currently approached viewport tiles.
    for (const [root,grid] of regions) {
      if (!root.isConnected) {root.removeEventListener('scroll',onRegionScroll);listeningRoots.delete(root);regions.delete(root);continue;}
      const view=root===rootScroll()?innerHeight:root.clientHeight;
      const low=Math.floor((root.scrollTop-view*.5)/cellSize),high=Math.floor((root.scrollTop+view*1.5)/cellSize);
      for(let cell=low;cell<=high;cell++) {
        const bucket=grid.get(cell);if(!bucket)continue;
        for(const e of bucket) {
          if(!e.isConnected){bucket.delete(e);continue;}
          if(nearRecheck.has(e) && !applied.has(e)) {dirtyRoots.add(e);nearRecheck.delete(e);stats.gridChecks++;}
        }
      }
    }
    if(dirtyRoots.size) schedule(100);
  }
  function remove(e) {
    if (!applied.has(e)) return;
    io?.unobserve(e);
    const wasFar=e.hasAttribute(FAR);
    e.removeAttribute(ATTR); e.removeAttribute(FAR);
    const o=originals.get(e);
    if (o) {
      if (o.had) e.style.setProperty(SIZE,o.value,o.priority);
      else e.style.removeProperty(SIZE);
    }
    if (wasFar) {farCount=Math.max(0,farCount-1);hiddenHeight=Math.max(0,hiddenHeight-(blockHeights.get(e)||0));}
    applied.delete(e);
  }
  function removeAll() {for (const e of applied) remove(e);farCount=0;hiddenHeight=0;totalScrollHeight=0;stats.contained=0;stats.far=0;stats.coverage=0;}
  function resetRegions() {
    scrollableCache=new WeakMap();
    for (const root of listeningRoots) root.removeEventListener('scroll',onRegionScroll);
    listeningRoots.clear();regions.clear();nearRecheck.clear();activeScrollRoot=null;
  }
  function cancel() {generation++;if(scheduled)clearTimeout(scheduled);if(pendingRescan)clearTimeout(pendingRescan);pendingRescan=0;scheduled=0;running=false;dirtyRoots.clear();fullRescan=true;resetRegions();fullRetries=0;if(regionTimer)cancelAnimationFrame(regionTimer);regionTimer=0;}
  function updateFar() {
    stats.far=farCount;
    stats.hiddenHeight=Math.round(hiddenHeight);
    // Height coverage is an estimate of the scroll range skipped, NOT CPU/RAM savings.
    stats.coverage=totalScrollHeight>0?Math.min(100,Math.round(hiddenHeight*100/totalScrollHeight)):0;
    stats.updatedAt=Date.now();
  }
  function intersection(events) {
    if (!active()) return;
    for (const ent of events) {
      if (!applied.has(ent.target)) continue;
      // A large prefetch margin avoids revealing a blank paragraph when scrolling normally.
      const hide=!ent.isIntersecting && !ent.target.contains(document.activeElement);
      if(ent.target.hasAttribute(FAR)!==hide){ent.target.toggleAttribute(FAR,hide);farCount+=hide?1:-1;hiddenHeight+= (hide?1:-1)*(blockHeights.get(ent.target)||0);}
    }
    updateFar();
    if (applied.size) stats.reason=`Containment active (${stats.far} blocks explicitly skipped)`;
  }
  function observer() {
    io?.disconnect();
    // scrollMargin expands the *nested scroller's* clipping rectangle, unlike rootMargin alone.
    // Small 96px buffer lets distant content skip sooner; visible blocks still render normally.
    io = new IntersectionObserver(intersection,{root:null,rootMargin:'0px',scrollMargin:'96px 0px 96px 0px',threshold:0});
    farCount=0;hiddenHeight=0;
    for (const e of applied) {
      e.removeAttribute(FAR);
      io.observe(e);
    }
    updateFar();
  }
  function roots() {return document.body?[document.body]:[];}
  function collect(scope) {
    const result=[],seen=new Set(),limit=12000;
    // Full discovery must visit the document once: preferential <main> traversal
    // previously duplicated DOM queries and could starve content outside <main>.
    for (const root of scope) {
      if (!root?.isConnected) continue;
      if (root.matches?.(CANDIDATES) && !seen.has(root)) {seen.add(root);result.push(root);}
      for (const e of root.querySelectorAll(CANDIDATES)) {
        if (!seen.has(e)) {seen.add(e);result.push(e);}
        if (result.length>=limit) return result;
      }
    }
    return result;
  }
  function contentLength(e) {
    // Never traverse a whole article's text to decide whether a wrapper is a block.
    if (e.childElementCount>12 && !LEAF.has(e.tagName)) return 0;
    return (e.textContent||'').trim().length;
  }
  function hasBlockChildren(e) {
    // Detect nested block structure, not only immediate children: complex apps
    // often wrap every paragraph in multiple invisible divs.
    return !!e.querySelector(CANDIDATES + ',table,details,summary,hr');
  }
  function candidate(e) {
    if (!e.isConnected || applied.has(e)) return reject('alreadyContained');
    if (geometryRejected.has(e)) return reject('geometryRejected');
    const leaf=LEAF.has(e.tagName);
    if (!leaf && !containerTags.has(e.tagName)) return reject('notCandidate');
    if (e.closest(OUTSIDE)) return reject('navigationOrEditable');
    if (e.contains(document.activeElement) && document.activeElement!==document.body) return reject('focused');
    if (e.querySelector(UNSAFE)) return reject('interactive');
    const lastEdit=edited.get(e);
    if (lastEdit && stamp()-lastEdit<850) { const sc=scrollParent(e);cacheCandidate(e,sc);nearRecheck.set(e,true);return reject('recentlyEdited'); }
    if (!leaf && !(e.tagName==='FIGURE' && e.querySelector('img,picture,svg')) && hasBlockChildren(e)) return reject('hasIndependentChildren');
    const len=contentLength(e);
    const media=!leaf && !!e.querySelector('img,svg,picture') && e.childElementCount<=5;
    // Small headings, one-line paragraphs, and brief list items must also be covered.
    if (!len && !media) return reject('emptyText');
    
    const s=getComputedStyle(e);
    if (!['block','flow-root','list-item','flex'].includes(s.display) ||
        (s.display==='flex' && !s.flexDirection.startsWith('column')) ||
        !['static','relative'].includes(s.position) || s.float!=='none' ||
        s.visibility!=='visible' || s.contentVisibility!=='visible' ||
        s.animationName!=='none' || s.transform!=='none' || s.filter!=='none' ||
        s.columnCount!=='auto' && s.columnCount!=='1' ||
        /scroll|auto/.test(s.overflowY) || /scroll|auto/.test(s.overflowX)) return reject('layoutStyle');
    // Do not modify a direct flex/grid item in a horizontal multi-column flow.
    const parent=e.parentElement;
    if (parent) {
      const ps=getComputedStyle(parent);
      if ((ps.display==='grid' && ps.gridTemplateColumns.split(' ').filter(Boolean).length>1) ||
          (ps.display==='flex' && ps.flexDirection.startsWith('row') && parent.childElementCount>1)) return reject('directMultiColumnItem');
    }
    if (!leaf && e.firstElementChild && e.lastElementChild &&
        !['flow-root','flex'].includes(s.display) && s.overflowY==='visible' &&
        !(['paddingTop','paddingBottom','borderTopWidth','borderBottomWidth'].some(k=>px(s[k])>0)) &&
        (px(getComputedStyle(e.firstElementChild).marginTop)>0 || px(getComputedStyle(e.lastElementChild).marginBottom)>0)) return reject('marginCollapse');
    const rect=e.getBoundingClientRect();
    if (rect.width<55 || rect.height<9 || rect.height>100000) return reject('notMeasurable');
    const scroller=scrollParent(e),view=scrollView(scroller);
    if (view.height<30) return reject('hiddenScroller');
    const extent=scroller.scrollHeight-scroller.clientHeight;
    if (extent<view.height*.6) return reject('shortScroller');
    if(!activeScrollRoot || extent>activeScrollRoot.scrollHeight-activeScrollRoot.clientHeight)activeScrollRoot=scroller;
    // Contain even currently visible blocks; the browser renders
    // them normally, and IntersectionObserver can hide them later without rescanning.
    const size=rect.height-['paddingTop','paddingBottom','borderTopWidth','borderBottomWidth'].reduce((sum,k)=>sum+px(s[k]),0);
    if (size<1 || !Number.isFinite(size)) return reject('unmeasurableBox');
    let depth=0;for(let p=e.parentElement;p;p=p.parentElement)depth++;
    cacheCandidate(e,scroller);
    return {e,scroller,size,depth};
  }
  function measure(roots) {return [...roots].map(e=>[e,e.scrollHeight,e.scrollTop]);}
  function movement(before) {return before.some(([e,height,top])=>Math.abs(e.scrollHeight-height)>4||Math.abs(e.scrollTop-top)>4);}
  function tryApply(batch) {
    const previous=measure(new Set(batch.map(x=>x.scroller)));
    for (const {e,size} of batch) {
      if (!originals.has(e)) originals.set(e,{had:e.style.getPropertyValue(SIZE)!=='',value:e.style.getPropertyValue(SIZE),priority:e.style.getPropertyPriority(SIZE)});
      e.style.setProperty(SIZE,`${size.toFixed(3)}px`);
      blockHeights.set(e,size);
      e.setAttribute(ATTR,'1');applied.add(e);
    }
    if (movement(previous)) {
      for (const {e} of batch) remove(e);
      return false;
    }
    for (const {e} of batch) io?.observe(e);
    return true;
  }
  function apply(batch) {
    if (!batch.length) return 0;
    if (tryApply(batch)) return batch.length;
    if (batch.length===1) {
      geometryRejected.add(batch[0].e);
      reasons.geometryRollback=(reasons.geometryRollback||0)+1;
      return 0;
    }
    // An unsafe wrapper must not invalidate 31 otherwise safe paragraphs.
    const half=batch.length>>1;
    return apply(batch.slice(0,half))+apply(batch.slice(half));
  }
  function finish(summary,ms,workMs) {
    stats.scanMs=Math.round(ms*10)/10;stats.workMs=Math.round(workMs*10)/10;
    stats.scans++;stats.contained=applied.size;running=false;updateFar();
    if (!active()) stats.reason='Disabled';
    else if (stats.contained) stats.reason='Native containment enabled';
    else if (reasons.geometryRollback) stats.reason='Scroll geometry changed; unsafe containment reverted';
    else stats.reason='No safe offscreen blocks; see rejection diagnostics';
    stats.rejections=Object.fromEntries(Object.entries(reasons).sort((a,b)=>b[1]-a[1]).slice(0,7));stats.cachedRegions=[...regions.values()].reduce((a,m)=>a+m.size,0);if(stats.scanType==='full')stats.fullScans++;else stats.localScans++;
    stats.scrollRoot=summary;
  }
  function scan() {
    scheduled=0;
    if (!active() || running || !document.body) return;
    running=true;scrollableCache=new WeakMap();const id=++generation,start=stamp();
    const all=fullRescan;const scope=all?roots():[...dirtyRoots];
    dirtyRoots.clear();fullRescan=false;
    let workMs=0;
    for (const k of Object.keys(reasons)) delete reasons[k];
    let blocks;
    try { if (lastUrl!==location.href) {removeAll();lastUrl=location.href;fullRescan=true;}
      blocks=collect(scope);stats.scanType=all?'full':'local';stats.scanned=blocks.length;stats.eligible=0;stats.added=0;
      for (const e of applied) if(!e.isConnected || !e.hasAttribute(ATTR)){
          if(e.hasAttribute(FAR)) {farCount=Math.max(0,farCount-1);hiddenHeight=Math.max(0,hiddenHeight-(blockHeights.get(e)||0));}
          applied.delete(e);
        }
    } catch (err) {running=false;stats.reason=`Collection error: ${err?.name||'unknown'}`;return;}
    let i=0,selected=[],observedScroll=new Set();
    function step() {
      if (id!==generation||!active()) {running=false;return;}
      const slice=stamp();
      try {
        while (i<blocks.length && stamp()-slice<6) {
          const candidateNode=blocks[i++],c=candidate(candidateNode);
          if (c) {stats.eligible++;observedScroll.add(c.scroller);selected.push(c);}
        }
        workMs+=stamp()-slice;const afterCandidates=stamp();
        if (i<blocks.length) {setTimeout(step,0);return;}
        // Prefer leaves: choose nonoverlapping descendants, never an outer wrapper plus its children.
        const priority=e=>e.tagName==='FIGURE'&&e.querySelector('img,picture,svg')?2:LEAF.has(e.tagName)?1:0;
        selected.sort((a,b)=>priority(b.e)-priority(a.e)||b.depth-a.depth);
        const limit=3000,batch=[];
        for (const c of selected) {
          if (applied.size+stats.added>=limit) break;
          // Reject ancestor/descendant overlap without O(candidates * contained).
          let nested=false;
          for(let p=c.e.parentElement;p;p=p.parentElement) if(applied.has(p)) {nested=true;break;}
          if(nested) continue;
          if(batch.some(x=>x.e.contains(c.e)||c.e.contains(x.e))) continue;
          // A parent may be considered after a previously accepted leaf.
          if(!LEAF.has(c.e.tagName) && (c.e.querySelector(`[${ATTR}]`) || batch.some(x=>c.e.contains(x.e)))) continue;
          batch.push(c);
          if (batch.length===32) {stats.added+=apply(batch);batch.length=0;}
        }
        if (batch.length) stats.added+=apply(batch);
        const any=observedScroll.values().next().value;
        const scroller=any || scrollerFromContent();
        const summary=rootLabel(scroller);
        totalScrollHeight=scroller?.scrollHeight||0;
        workMs+=stamp()-afterCandidates;finish(summary,stamp()-start,workMs);
      } catch(err) {running=false;stats.reason=`Scan error: ${err?.message||'unknown'}`;}
      if(!running && (fullRescan || dirtyRoots.size)) schedule(200);
      else if(!running && all && !applied.size && fullRetries++<3) {
        fullRescan=true;schedule(650*fullRetries);
      }
    }
    step();
  }
  function schedule(delay=400) {
    if (!active() || scheduled) return;
    scheduled=setTimeout(scan,delay);
  }
  function setSettings(changes) {
    const wasActive=active();
    for (const [k,v] of Object.entries(changes)) settings[k]=v;
    settings.excludedHosts=Array.isArray(settings.excludedHosts)?settings.excludedHosts:[];
    if(wasActive===active())return; // Changing a different site's exclusion must not rescan this tab.
    if(!active()){cancel();removeAll();stats.reason='Disabled';return;}
    cancel();removeAll();observer();schedule(150);
  }
  chrome.storage.local.get({enabled:true,excludedHosts:[]},defaults=>{
    if (chrome.runtime.lastError) return;
    settings={...defaults,excludedHosts:Array.isArray(defaults.excludedHosts)?defaults.excludedHosts:[]};
    observer();if (active()) schedule(150);
    function scheduleLocalUpdate() {
      lastMutationAt=stamp();
      if(pendingRescan) return;
      const flush=()=>{
        const remaining=950-(stamp()-lastMutationAt);
        if(remaining>0){pendingRescan=setTimeout(flush,remaining);return;}
        pendingRescan=0;schedule(100);
      };
      pendingRescan=setTimeout(flush,950);
    }
    watcher=new MutationObserver(records=>{
      if (!active()) return;
      if(lastUrl!==location.href){lastUrl=location.href;removeAll();resetRegions();fullRescan=true;}
      let structural=false;
      const now=stamp();
      for (const r of records) {
        const target=r.target.nodeType===1?r.target:r.target.parentElement;
        if (!target?.isConnected) continue;
        let block=target.closest(LEAVES+',figure,div,section,article');
        // Text may be edited inside a contained div that is not a semantic paragraph.
        for(let p=target,n=0;p&&n<20;p=p.parentElement,n++){
          if(applied.has(p)) {remove(p);block=p;break;}
        }
        if (r.type==='characterData') {
          if (block) {edited.set(block,now);dirtyRoots.add(block);structural=true;}
          continue;
        }
        let additions=false;
        for (const node of r.addedNodes) {
          if (node.nodeType!==1) continue;
          if (node.matches?.(CANDIDATES) || node.querySelector?.(CANDIDATES)) {
            dirtyRoots.add(node);additions=true;
          }
        }
        if (additions) structural=true;
        else if (block) {edited.set(block,now);dirtyRoots.add(block);structural=true;}
      }
      if (structural) scheduleLocalUpdate();
    });
    watcher.observe(document.body,{subtree:true,childList:true,characterData:true});
    // Contain near blocks up front, then let IntersectionObserver handle scrolling.
    // Do not rescan the entire DOM on every scroll: it causes long main-thread stalls.
    addEventListener('scroll',onRegionScroll,{passive:true});
    addEventListener('resize',()=>{removeAll();resetRegions();fullRescan=true;schedule(450);},{passive:true});
    addEventListener('pageshow',()=>{fullRescan=true;schedule(350);});
  });
  chrome.storage.onChanged.addListener((changes,where)=>{
    if(where!=='local')return;
    const updates=Object.fromEntries(Object.entries(changes).filter(([k])=>['enabled','excludedHosts'].includes(k)).map(([k,v])=>[k,v.newValue]));
    if(Object.keys(updates).length)setSettings(updates);
  });
  chrome.runtime.onMessage.addListener((msg,_sender,send)=>{
    if (msg?.type!=='status') return;
    updateFar();send({...stats,contained:applied.size,far:farCount,gridCells:stats.cachedRegions,gridChecks:stats.gridChecks,
      darkReaderDetected:!!document.querySelector('meta[name="darkreader"],style.darkreader'),url:location.href});
  });
})();
